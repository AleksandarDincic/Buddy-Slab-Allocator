#include "slab.h"
#include <stdio.h>

void consty(void* p) {
	printf("konstruktor a adresa je %d\n", p);
}

void destry(void* p) {
	printf("destruktor a adresa je %d\n", p);
}

void main() {
	int size = 256;
	char* mem = malloc(size * BLOCK_SIZE);
	/*BuddyMetadata* buddy =buddy_init(mem, 256);
	BuddyBlock* blocks = buddy_take(buddy, 128 * BLOCK_SIZE);
	for (int i = 0; i < 128; i++) {
		buddy_give(buddy, blocks + i, BLOCK_SIZE);
	}*/
	kmem_init(mem, size);
	kmem_cache_t* test = kmem_cache_create("nikola", 1, &consty, &destry);
	/*void* yo = kmem_cache_alloc(test);
	kmem_cache_info(test);
	kmem_cache_free(test, yo);
	kmem_cache_free(test, 124124);
	kmem_cache_info(test);
	kmem_cache_shrink(test);
	kmem_cache_shrink(test);
	kmem_cache_info(test);
	kmem_cache_destroy(test);*/
	void* eh = kmalloc(32);
	kfree(eh);
	return;
}